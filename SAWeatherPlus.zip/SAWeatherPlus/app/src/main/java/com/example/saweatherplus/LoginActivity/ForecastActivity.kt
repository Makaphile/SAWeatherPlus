package com.saweatherplus

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.annotations.SerializedName
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

class ForecastActivity : AppCompatActivity() {

    private lateinit var hourlyContainer: LinearLayout
    private lateinit var dailyContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forecast)

        hourlyContainer = findViewById(R.id.hourlyContainer)
        dailyContainer = findViewById(R.id.dailyContainer)

        fetchWeather("Durban") // Change to user's city
    }

    private fun fetchWeather(city: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(OpenWeatherMapService::class.java)
        service.getForecast(city, BuildConfig.OPEN_WEATHER_MAP_API_KEY, "metric").enqueue(object : Callback<WeatherResponse> {
            override fun onResponse(call: Call<WeatherResponse>, response: Response<WeatherResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    displayHourlyForecast(response.body()!!)
                    displayDailyForecast(response.body()!!)
                }
            }

            override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                t.printStackTrace()
            }
        })
    }

    private fun displayHourlyForecast(weather: WeatherResponse) {
        hourlyContainer.removeAllViews()

        for (hour in weather.hourly) {
            val card = layoutInflater.inflate(R.layout.forecast_hourly_card, hourlyContainer, false)

            val tvTime = card.findViewById<TextView>(R.id.tvTime)
            val ivIcon = card.findViewById<ImageView>(R.id.ivWeatherIcon)
            val tvTemp = card.findViewById<TextView>(R.id.tvTemp)

            tvTime.text = hour.time
            tvTemp.text = "${hour.temp}°C"

            ivIcon.setImageResource(getWeatherIcon(hour.weather[0].main))

            hourlyContainer.addView(card)
        }
    }

    private fun displayDailyForecast(weather: WeatherResponse) {
        dailyContainer.removeAllViews()

        for (day in weather.daily) {
            val card = layoutInflater.inflate(R.layout.forecast_daily_card, dailyContainer, false)

            val tvDate = card.findViewById<TextView>(R.id.tvDate)
            val ivIcon = card.findViewById<ImageView>(R.id.ivWeatherIcon)
            val tvTempMin = card.findViewById<TextView>(R.id.tvTempMin)
            val tvTempMax = card.findViewById<TextView>(R.id.tvTempMax)

            tvDate.text = day.date
            tvTempMin.text = "Min: ${day.tempMin}°C"
            tvTempMax.text = "Max: ${day.tempMax}°C"

            ivIcon.setImageResource(getWeatherIcon(day.weather[0].main))

            dailyContainer.addView(card)
        }
    }

    private fun getWeatherIcon(condition: String): Int {
        return when (condition.lowercase()) {
            "clear" -> R.drawable.sun
            "clouds" -> R.drawable.cloud
            "rain" -> R.drawable.rain
            "snow" -> R.drawable.snow
            "storm", "thunderstorm" -> R.drawable.storm
            else -> R.drawable.cloud
        }
    }
}

/** Retrofit API Interface */
interface OpenWeatherMapService {
    @GET("onecall")
    fun getForecast(
        @Query("q") city: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String
    ): Call<WeatherResponse>
}

/** Data models for JSON parsing */
data class WeatherResponse(
    @SerializedName("hourly") val hourly: List<HourlyForecast>,
    @SerializedName("daily") val daily: List<DailyForecast>
)

data class HourlyForecast(
    @SerializedName("dt") val dt: Long,
    @SerializedName("temp") val temp: Double,
    @SerializedName("weather") val weather: List<WeatherCondition>
) {
    val time: String
        get() = java.text.SimpleDateFormat("HH:mm").format(java.util.Date(dt * 1000))
}

data class DailyForecast(
    @SerializedName("dt") val dt: Long,
    @SerializedName("temp") val temp: Temp,
    @SerializedName("weather") val weather: List<WeatherCondition>
) {
    val date: String
        get() = java.text.SimpleDateFormat("EEE, MMM d").format(java.util.Date(dt * 1000))
    val tempMin: Double
        get() = temp.min
    val tempMax: Double
        get() = temp.max
}

data class Temp(
    @SerializedName("min") val min: Double,
    @SerializedName("max") val max: Double
)

data class WeatherCondition(
    @SerializedName("main") val main: String,
    @SerializedName("description") val description: String
)
