package com.saweatherplus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btnForecast = findViewById<Button>(R.id.btnForecast)
        val btnSettings = findViewById<Button>(R.id.btnSettings)

        btnForecast.setOnClickListener {
            startActivity(Intent(this, ForecastActivity::class.java))
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}
